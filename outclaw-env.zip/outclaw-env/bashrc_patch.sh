## ═══════════════════════════════════════════════════════════════
##  ~/.bashrc patch — BleakNarratives / ShipWrekD OS
##
##  APPEND this block to the bottom of your ~/.bashrc on any device.
##  Source it immediately with:  source ~/.bashrc
## ═══════════════════════════════════════════════════════════════

## ── TERMINAL SIZE FIX ──────────────────────────────────────────
## Crostini zoom-to-fix bug: bash wasn't re-checking window size.
## This makes every command completion re-query the real dimensions.
shopt -s checkwinsize

## Force-sync on shell startup (catches stale LINES/COLUMNS)
if command -v resize &>/dev/null; then
    eval "$(resize 2>/dev/null)" 2>/dev/null
else
    ## resize not installed — send a SIGWINCH to ourselves to trigger redraw
    kill -SIGWINCH $$ 2>/dev/null
fi

## Re-sync on every actual resize event too
trap 'shopt -s checkwinsize; kill -SIGWINCH $$ 2>/dev/null' SIGWINCH


## ── SHIPWREKD ENVIRONMENT ──────────────────────────────────────
export ROOTBASE_HOME="${ROOTBASE_HOME:-$HOME/rootbase}"
export BACKTAG_REGISTRY="$ROOTBASE_HOME/backtag_registry.jsonl"
export SCRIPTS_DIR="$HOME/.scripts"
mkdir -p "$SCRIPTS_DIR" "$ROOTBASE_HOME"


## ── NANO WRAPPER ───────────────────────────────────────────────
## Intercepts every nano call to:
##   1) Load a per-project .nanorc.local if one exists in the project tree
##   2) Run the backtag hook on any file whose mtime changed after editing
##
## This IS the "bashrc for nano" pattern — every file that runs through
## nano gets processed on save, automatically, with no extra commands.
nano() {
    ## ── Separate flags from file args ──────────────────────────
    local -a flags=()
    local -a targets=()
    for arg in "$@"; do
        if [[ "$arg" == -* ]]; then
            flags+=("$arg")
        else
            targets+=("$arg")
        fi
    done

    ## ── Snapshot mtimes before editing ─────────────────────────
    local -A before_mtimes=()
    for f in "${targets[@]}"; do
        before_mtimes["$f"]=$(stat -c %Y "$f" 2>/dev/null || echo 0)
    done

    ## ── Find per-project .nanorc.local ─────────────────────────
    ## Walk up from cwd until we hit a .nanorc.local or / 
    local local_rc=""
    local walk_dir
    walk_dir=$(pwd)
    while [[ "$walk_dir" != "/" ]]; do
        if [[ -f "$walk_dir/.nanorc.local" ]]; then
            local_rc="$walk_dir/.nanorc.local"
            break
        fi
        walk_dir=$(dirname "$walk_dir")
    done

    ## ── Launch nano ────────────────────────────────────────────
    if [[ -n "$local_rc" ]]; then
        ## Merge global + local into a temp rc file
        local tmprc
        tmprc=$(mktemp /tmp/.nanorc.merged.XXXXXX)
        cat "$HOME/.nanorc" "$local_rc" > "$tmprc"
        command nano --rcfile="$tmprc" "${flags[@]}" "${targets[@]}"
        local exit_code=$?
        rm -f "$tmprc"
    else
        command nano "${flags[@]}" "${targets[@]}"
        local exit_code=$?
    fi

    ## ── Post-save: run backtag hook on modified files ──────────
    for f in "${targets[@]}"; do
        local after_mtime
        after_mtime=$(stat -c %Y "$f" 2>/dev/null || echo 0)
        if [[ "${before_mtimes[$f]}" != "$after_mtime" && -f "$f" ]]; then
            if [[ -x "$SCRIPTS_DIR/backtag.sh" ]]; then
                "$SCRIPTS_DIR/backtag.sh" "$f" &   # run async; don't block prompt
            fi
        fi
    done

    return $exit_code
}
export -f nano


## ── PRETTY PROMPT ──────────────────────────────────────────────
## Two-line prompt: [device tag] path (git branch if in repo)
## ☕ for Crostini, 🔺 for A9, 📱 for phone — set DEVICE_TAG in
## /etc/environment or at top of .bashrc to differentiate.
DEVICE_TAG="${DEVICE_TAG:-☕}"

__git_branch() {
    local branch
    branch=$(git symbolic-ref --short HEAD 2>/dev/null \
             || git rev-parse --short HEAD 2>/dev/null) || return
    echo " ($branch)"
}

## Colors
_C_RESET='\[\e[0m\]'
_C_CYAN='\[\e[36m\]'
_C_YELLOW='\[\e[33m\]'
_C_MAGENTA='\[\e[35m\]'
_C_BOLD='\[\e[1m\]'

PS1="${_C_BOLD}${_C_CYAN}${DEVICE_TAG} ${_C_YELLOW}\w${_C_MAGENTA}\$(__git_branch)${_C_RESET}\n${_C_CYAN}▸${_C_RESET} "

## ── QUALITY-OF-LIFE ALIASES ────────────────────────────────────
alias ll='ls -lAh --color=auto'
alias la='ls -A --color=auto'
alias ..='cd ..'
alias ...='cd ../..'

## backtag query helpers
alias bt-log="cat \$BACKTAG_REGISTRY 2>/dev/null | tail -40"
alias bt-search="grep -i"                         # usage: bt-search outclaw
alias bt-last="cat \$BACKTAG_REGISTRY 2>/dev/null | tail -1 | python3 -m json.tool"

## OutClaw shortcut
alias outclaw="python3 \$ROOTBASE_HOME/outclaw/outclaw_validator.py"
