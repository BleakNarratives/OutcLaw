#!/usr/bin/env bash
## ═══════════════════════════════════════════════════════════════
##  install.sh — drops the ShipWrekD nano/shell environment
##  Run this on any device after rclone-pulling the zip.
##
##  Usage:
##    chmod +x install.sh && ./install.sh [--device TAG]
##
##  TAG examples: ☕  🔺  📱
## ═══════════════════════════════════════════════════════════════

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DEVICE_TAG="${2:-}"
[[ -z "$DEVICE_TAG" && "${1:-}" == "--device" ]] && DEVICE_TAG="${2:-}"

## ── DEVICE TAG ─────────────────────────────────────────────────
if [[ -z "$DEVICE_TAG" ]]; then
    echo "What device is this?"
    echo "  1) ☕  Chromebook/Crostini"
    echo "  2) 🔺  A9 Tablet"
    echo "  3) 📱  Phone"
    read -rp "Choice [1-3]: " choice
    case "$choice" in
        1) DEVICE_TAG="☕" ;;
        2) DEVICE_TAG="🔺" ;;
        3) DEVICE_TAG="📱" ;;
        *) DEVICE_TAG="?" ;;
    esac
fi

echo "→ Device: $DEVICE_TAG"

## ── NANORC ─────────────────────────────────────────────────────
cp -v "$SCRIPT_DIR/nanorc" "$HOME/.nanorc"
echo "✓ ~/.nanorc installed"

## ── BACKTAG SCRIPT ─────────────────────────────────────────────
mkdir -p "$HOME/.scripts"
cp -v "$SCRIPT_DIR/scripts/backtag.sh" "$HOME/.scripts/backtag.sh"
chmod +x "$HOME/.scripts/backtag.sh"
echo "✓ ~/.scripts/backtag.sh installed"

## ── BASHRC PATCH ───────────────────────────────────────────────
MARKER="## ShipWrekD OS bashrc patch"
if grep -q "$MARKER" "$HOME/.bashrc" 2>/dev/null; then
    echo "⚠  bashrc_patch already present — skipping (remove old block first if you want to update)"
else
    {
        echo ""
        echo "$MARKER"
        echo "export DEVICE_TAG='$DEVICE_TAG'"
        cat "$SCRIPT_DIR/bashrc_patch.sh"
    } >> "$HOME/.bashrc"
    echo "✓ ~/.bashrc patched"
fi

## ── SOURCE IT ──────────────────────────────────────────────────
echo ""
echo "All done. Run:  source ~/.bashrc"
echo "Then open a file with nano to confirm the wrapper is live."
echo "Registry will appear at: \$ROOTBASE_HOME/backtag_registry.jsonl"
