#!/usr/bin/env bash
## ═══════════════════════════════════════════════════════════════
##  ~/.scripts/backtag.sh
##
##  Called automatically by the nano() wrapper in .bashrc every
##  time a file is saved through nano (mtime changed).
##
##  Writes a JSONL entry to $BACKTAG_REGISTRY — non-destructive,
##  never modifies the source file. Registry is queryable with jq.
##
##  Extend the module_from_path() and tag_from_content() functions
##  as the codebase grows.
## ═══════════════════════════════════════════════════════════════

set -euo pipefail

FILE="${1:-}"
if [[ -z "$FILE" || ! -f "$FILE" ]]; then
    exit 0   # nothing to tag
fi

## ── REGISTRY LOCATION ──────────────────────────────────────────
ROOTBASE_HOME="${ROOTBASE_HOME:-$HOME/rootbase}"
REGISTRY="${BACKTAG_REGISTRY:-$ROOTBASE_HOME/backtag_registry.jsonl}"
mkdir -p "$(dirname "$REGISTRY")"

## ── MODULE DETECTION ───────────────────────────────────────────
## Extend this as you add modules to RootBase
module_from_path() {
    local p="$1"
    case "$p" in
        *outclaw*)      echo "outclaw"      ;;
        *truthsleuth*)  echo "truthsleuth"  ;;
        *rootbase*)     echo "rootbase"     ;;
        *shipwrekd*)    echo "shipwrekd"    ;;
        *scripts/*)     echo "scripts"      ;;
        *.bashrc*|*.nanorc*|*.profile*) echo "env" ;;
        *)              echo "unknown"      ;;
    esac
}

## ── CONTENT TAG DETECTION ──────────────────────────────────────
## Scans the first 60 lines for known ShipWrekD/OutClaw markers
tag_from_content() {
    local p="$1"
    local tags=()

    head -60 "$p" 2>/dev/null | grep -q "DRAFT_BLOCK\|HARD_BLOCK" \
        && tags+=("draft-blocked")
    head -60 "$p" 2>/dev/null | grep -qE "TODO|FIXME|HACK|XXX" \
        && tags+=("has-todo")
    head -60 "$p" 2>/dev/null | grep -qE "\[BACKTAG\]|backtag:" \
        && tags+=("already-tagged")
    head -60 "$p" 2>/dev/null | grep -qE "U\.S\.C\.|C\.F\.R\.|§" \
        && tags+=("has-citations")
    head -1 "$p" 2>/dev/null | grep -q "^#!/" \
        && tags+=("executable")

    ## Output comma-joined or "none"
    if [[ ${#tags[@]} -gt 0 ]]; then
        local IFS=','
        echo "${tags[*]}"
    else
        echo "none"
    fi
}

## ── GATHER METADATA ────────────────────────────────────────────
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
ABS_FILE=$(realpath "$FILE" 2>/dev/null || echo "$FILE")
EXTENSION="${FILE##*.}"
MODULE=$(module_from_path "$ABS_FILE")
CONTENT_TAGS=$(tag_from_content "$ABS_FILE")
FILESIZE=$(stat -c %s "$ABS_FILE" 2>/dev/null || echo 0)

## SHA-256: use sha256sum (Linux/Termux) with sha256 fallback (macOS)
if command -v sha256sum &>/dev/null; then
    HASH=$(sha256sum "$ABS_FILE" | cut -d' ' -f1)
else
    HASH=$(sha256 -q "$ABS_FILE" 2>/dev/null || echo "unavailable")
fi

## Device tag from env (set DEVICE_TAG in /etc/environment)
DEVICE="${DEVICE_TAG:-unknown}"

## ── WRITE REGISTRY ENTRY ───────────────────────────────────────
## Newline-delimited JSON — query with: jq '.' $BACKTAG_REGISTRY
## or: grep '"module":"outclaw"' $BACKTAG_REGISTRY | jq .
printf '{"ts":"%s","file":"%s","ext":"%s","module":"%s","tags":"%s","bytes":%s,"sha256":"%s","device":"%s"}\n' \
    "$TIMESTAMP" \
    "$ABS_FILE" \
    "$EXTENSION" \
    "$MODULE" \
    "$CONTENT_TAGS" \
    "$FILESIZE" \
    "$HASH" \
    "$DEVICE" \
    >> "$REGISTRY"

## ── OPTIONAL: INLINE BACKTAG HEADER ───────────────────────────
## Uncomment this block to auto-inject a [BACKTAG] header comment
## into Python/Shell files that don't have one yet.
## This is the "write into every file" mode — use deliberately.
##
## insert_backtag_header() {
##     local f="$1"
##     head -5 "$f" | grep -q "\[BACKTAG\]" && return  # already tagged
##     local ext="${f##*.}"
##     local marker="# [BACKTAG] module=${MODULE} tagged=${TIMESTAMP} device=${DEVICE}"
##     case "$ext" in
##         py|sh|bash)
##             ## Insert after shebang if present, else line 1
##             if head -1 "$f" | grep -q "^#!"; then
##                 sed -i "1a\\${marker}" "$f"
##             else
##                 sed -i "1i\\${marker}" "$f"
##             fi
##             ;;
##     esac
## }
## insert_backtag_header "$ABS_FILE"
